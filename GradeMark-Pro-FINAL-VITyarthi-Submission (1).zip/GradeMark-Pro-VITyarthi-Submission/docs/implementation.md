# Implementation Details

## GUI
`main.py` creates the Tkinter application and connects the three user-facing modules.

## Student Management
`student_manager.py` provides add, update, delete and find operations and rejects duplicate roll numbers.

## Data Persistence
`data_manager.py` loads and saves student records in `students.json`.

## Grade Calculation
`grade_utils.py` implements percentage, grade, grade-point and pass/fail logic.

## Calculator
`calculator.py` validates marks and returns percentage, grade and grade points.

## Dashboard
`dashboard.py` calculates total students, average marks, passed count and failed count.

## Validation
`validation.py` checks required fields, numeric marks, valid ranges and calculator constraints.
