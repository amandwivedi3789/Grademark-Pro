# Testing Report

## Automated Tests

Run:

```bash
python -m unittest discover -s tests -p "test_*.py"
```

Covered:
- Percentage calculation
- A+ grade boundary
- A grade boundary
- F grade boundary
- Pass boundary at 40
- Fail boundary below 40

## Manual Test Cases

| ID | Test | Expected result |
|---|---|---|
| T01 | Add valid student | Student appears in table and JSON |
| T02 | Duplicate roll number | Error is shown |
| T03 | Edit student | Selected record is updated |
| T04 | Delete student | Selected record is removed |
| T05 | Empty field | Validation error |
| T06 | Marks outside 0–100 | Validation error |
| T07 | Valid calculator input | Percentage/grade displayed |
| T08 | Invalid calculator input | Error is shown |
| T09 | Restart application | Saved records reload |
| T10 | Dashboard after CRUD | Statistics update |
