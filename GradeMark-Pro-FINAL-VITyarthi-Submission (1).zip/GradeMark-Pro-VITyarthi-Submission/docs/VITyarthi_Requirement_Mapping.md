# VITyarthi Requirement Mapping

This document maps GradeMark Pro to the supplied VITyarthi Build Your Own Project guidelines.

| VITyarthi requirement | GradeMark Pro evidence |
|---|---|
| 3 major functional modules | Dashboard, Student Management, Marks Calculator |
| Clear input/output | Student and marks forms produce records, statistics and grade results |
| Logical workflow | `docs/diagrams/workflow.png` |
| CRUD | Add, edit, delete and find student records |
| 4+ non-functional requirements | Usability, reliability, maintainability, error handling, resource efficiency |
| Proper architecture | Modular Python architecture documented in `architecture.md` |
| Clean implementation | Separate GUI, CRUD, storage, validation, grading, calculator and dashboard modules |
| Validation/error handling | `validation.py` and GUI error dialogs |
| Git/version control readiness | `.gitignore`, `README.md`, `GITHUB_SETUP.md` |
| 5–10 meaningful modules/files | 8 functional Python modules plus tests/configuration |
| Testing | `tests/test_grade_utils.py` and `docs/testing_report.md` |
| Problem statement | `statement.md` and project report |
| Objectives | `README.md` and project report |
| System Architecture | `docs/diagrams/system_architecture.png` |
| Workflow | `docs/diagrams/workflow.png` |
| Use Case | `docs/diagrams/use_case.png` |
| Class/Component | `docs/diagrams/class_diagram.png` |
| Sequence | `docs/diagrams/sequence.png` |
| Storage/ER design | `docs/diagrams/er_diagram.png` |
| README.md | Root `README.md` |
| statement.md | Root `statement.md` |
| Source/data/configuration | Python files, `students.json`, `requirements.txt` |
| Project report | `docs/GradeMark_Pro_Project_Report.pdf` |
