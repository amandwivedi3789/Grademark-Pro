# Final VITyarthi Submission Checklist

## Project implementation
- [x] Three major functional modules
- [x] Clear input/output
- [x] Logical workflow
- [x] Student CRUD
- [x] Marks/grade calculator
- [x] Dashboard statistics
- [x] Validation and error handling
- [x] Persistent JSON storage
- [x] Modular structure with meaningful Python files
- [x] Unit tests

## Repository
- [x] README.md
- [x] statement.md
- [x] Source code
- [x] Data/configuration files
- [x] Tests
- [x] GitHub setup guide
- [x] Design documentation
- [x] Six required diagrams
- [x] Screenshots
- [x] Project report PDF

## Before final upload
- [ ] Fill in your name, registration/roll number, course, faculty and institution on the PDF cover.
- [ ] Run `python main.py` and verify the application.
- [ ] Run `python -m unittest discover -s tests -p "test_*.py"`.
- [ ] Verify Add/Edit/Delete and calculator behavior.
- [ ] Verify records remain after restarting the application.
- [ ] If your evaluator requires machine-captured screenshots, replace the included project screenshots with screenshots from your own computer.
- [ ] Create and push the GitHub repository.
- [ ] Submit the GitHub repository and PDF through the VITyarthi portal according to the course instructions.
