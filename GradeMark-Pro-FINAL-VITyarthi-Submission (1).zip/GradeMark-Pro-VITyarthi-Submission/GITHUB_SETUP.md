# GitHub Setup

1. Create a GitHub repository named `GradeMark-Pro`.
2. Extract this folder and open a terminal in it.
3. Run:

```bash
git init
git add .
git commit -m "Initial GradeMark Pro project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

4. Verify that GitHub contains `README.md`, `statement.md`, source code, tests, docs, screenshots, data and configuration files.

Do not commit passwords, API keys or other secrets.
