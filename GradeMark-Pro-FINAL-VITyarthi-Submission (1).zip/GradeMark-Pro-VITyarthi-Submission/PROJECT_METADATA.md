# Project Metadata

Project Title: GradeMark Pro
Project Type: Python Tkinter desktop application
Primary Language: Python 3
Storage: JSON (`students.json`)
Testing: Python `unittest`
Main Modules: Dashboard, Student Management, Marks Calculator

This package was prepared against the supplied VITyarthi Build Your Own Project General Project Instructions & Submission Guidelines.
